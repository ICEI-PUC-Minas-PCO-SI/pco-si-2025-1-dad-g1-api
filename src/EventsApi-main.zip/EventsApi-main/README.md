# EventsApi
Api para gerenciar eventos
